#### 1.1.0 (2020-12-28)

##### Chores

*  rebuild webtour.js ([54990ef2](https://github.com/votch18/WebTour/commit/54990ef2e7d9921e8068a0d8ee80ee8c55632acd))
*  Add changelog ([9aa4503b](https://github.com/votch18/WebTour/commit/9aa4503b49bb558c0c850e47b84087403a6ccb8f))

##### Documentation Changes

*  Update version ([8925c218](https://github.com/votch18/WebTour/commit/8925c218723f7243949349254418ff0733e91304))

#### 1.1.0 (2020-12-28)

